# Agent DevTools — agent handoff

Run `BOOTSTRAP_AGENT_DEVTOOLS.py` from the intended workspace root, or run the single-file installer directly. No separate installation prompt is required.

Bootstrap is **universal-first**:

- an empty/unclassified workspace first receives the lightweight non-development core (`general`) without inventing a language, framework, test runner, or build system;
- only after that core exists, interactive use asks **what the user plans to do or discuss**; agent/noninteractive use reports `needs-intent` and tells the agent to ask that same human question;
- if the intent is development, ask for stack details only when they are still missing, then specialize the existing workspace into the matching development preset without discarding accumulated requirements/knowledge;
- an existing repository is **evidence-first**: inspect project files and metadata and infer the stack automatically. Do not ask the human to repeat a stack already visible in the repository;
- when an existing stack is recognized but no bundled preset safely represents it, report the detected stack and inspect project-native test/build commands before asking only for genuinely missing configuration decisions.

The user should not need to know or select Agent DevTools' internal `general`, `research`, `analysis`, `document`, or `development` profiles during normal onboarding. Profiles are an implementation detail inferred from intent/evidence unless explicitly overridden.

After installation, read `AGENTS.md`, then use `python devtools/agent/agent.py workflow show` and `capabilities --json` as the authoritative workflow/CLI discovery surface.

For research work, prefer the native semantic flow: requirements/open questions/evidence in cognition, tracked source provenance, durable promotion only for lasting knowledge, structured research verification, and portable workspace snapshots for handoff or archival.

Do not copy `.agent-cache/`, raw `.agent-work/`, or `devtools/agent/` as durable knowledge.
